export default {
  COLORS: {
    DARK_900: "#000000",
    ORANGE_900: "#F99701",
    RED_900: "#FB4F09",   
  }
}